# PyTorch
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

# 数据处理需要的包
import numpy as np
import csv
import os

# 画图需要的包
import matplotlib.pyplot as plt
from matplotlib.pyplot import figure

myseed = 42069  # 设立随机种子，确保可复现性
torch.backends.cudnn.deterministic = True#使CuDNN使用确定性算法
torch.backends.cudnn.benchmark = False# 禁用自动寻找最优算法
np.random.seed(myseed)
torch.manual_seed(myseed)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(myseed)

#设备检测函数
def get_device():
    ''' Get device (if GPU is available, use GPU) '''
    return 'cuda' if torch.cuda.is_available() else 'cpu'

#绘制学习曲线函数

'''
绘制训练过程中训练集和验证集的损失曲线，用于分析模型是否过拟合或欠拟合。
自动处理训练集和验证集记录频率不同的问题（通过x_2步长调整）。
设置固定的 Y 轴范围（0.0 到 5.0），便于比较不同模型的表现。
'''
def plot_learning_curve(loss_record, title=''):
    ''' Plot learning curve of your DNN (train & dev loss) '''
    #计算损失的总步数，创建训练损失的x坐标
    total_steps = len(loss_record['train'])
    x_1 = range(total_steps)
    #计算验证损失的x坐标
    x_2 = x_1[::len(loss_record['train']) // len(loss_record['dev'])]
    figure(figsize=(6, 4))
    #训练损失曲线，红色
    #验证损失曲线，蓝色
    plt.plot(x_1, loss_record['train'], c='tab:red', label='train')
    plt.plot(x_2, loss_record['dev'], c='tab:cyan', label='dev')
    #y轴的范围从0到5.0
    plt.ylim(0.0, 5.)
    #设置x，y轴的标签
    plt.xlabel('Training steps')
    plt.ylabel('MSE loss')
    plt.title('Learning curve of {}'.format(title))
    plt.legend()
    plt.show()

#可视化预测结果
'''
生成模型对验证集的预测结果，并与真实标签对比。
绘制散点图，其中：
X 轴：真实值（ground truth）
Y 轴：预测值（prediction）
蓝色对角线：理想情况下预测值应与真实值完全一致，即点落在这条线上。
直观评估模型预测的准确性和偏差。若点偏离对角线较远，说明模型存在较大误差；若点分布在对角线附近但有系统性偏移，说明模型存在偏差。
'''
def plot_pred(dv_set, model, device, lim=35., preds=None, targets=None):

    #生成预测结果
    if preds is None or targets is None:
        model.eval()# 将模型设为评估模式
        preds, targets = [], []# 初始化存储列表
        # 遍历验证集的每个批次
        for x, y in dv_set:
            x, y = x.to(device), y.to(device)
            # 禁用梯度计算（节省内存并加速推理）
            with torch.no_grad():
                pred = model(x) # 模型预测
                preds.append(pred.detach().cpu()) # 将预测结果移回CPU并存储
                targets.append(y.detach().cpu())# 将真实标签移回CPU并存储
        # 将所有批次的结果拼接为完整的numpy数组
        preds = torch.cat(preds, dim=0).numpy()
        targets = torch.cat(targets, dim=0).numpy()

    figure(figsize=(5, 5))
    plt.scatter(targets, preds, c='r', alpha=0.5)# 绘制散点图：X轴为真实值，Y轴为预测值
    plt.plot([-0.2, lim], [-0.2, lim], c='b')
    plt.xlim(-0.2, lim)
    plt.ylim(-0.2, lim)
    plt.xlabel('ground truth value')
    plt.ylabel('predicted value')
    plt.title('Ground Truth v.s. Prediction')
    plt.show()

#继承自 PyTorch 的Dataset基类，需实现__getitem__和__len__方法
#用于加载和预处理COVID-19相关数据
class COVID19Dataset(Dataset):
    ''' Dataset for loading and preprocessing the COVID19 dataset '''

    def __init__(self,
                 path,
                 mode='train',
                 target_only=False):
        self.mode = mode

        # 读取数据转换为numpy数组
        with open(path, 'r') as fp:
            data = list(csv.reader(fp))
            #跳过表头，然后转为array，然后抛去第一列（id），然后转为float
            data = np.array(data[1:])[:, 1:].astype(float)

        if not target_only:#是否仅使用部分特征
            feats = list(range(93)) # 使用全部特征
        else:
            # TODO: Using 40 states & 2 tested_positive features (indices = 57 & 75)
            #pass
            feats = list(range(40)) + [57, 75]  # 只使用前40个state特征和2个测试结果特征

        if mode == 'test':
            # 测试数据，仅保留特征
            # data: 893 x 93 (40 states + day 1 (18) + day 2 (18) + day 3 (17))
            data = data[:, feats]
            self.data = torch.FloatTensor(data)
        else:
            #训练或验证数据，多一列目标值
            # data: 2700 x 94 (40 states + day 1 (18) + day 2 (18) + day 3 (18))
            target = data[:, -1]#最后一列作为目标值
            data = data[:, feats]

            # 划分训练集和验证集
            if mode == 'train':
                indices = [i for i in range(len(data)) if i % 10 != 0]
            elif mode == 'dev':
                indices = [i for i in range(len(data)) if i % 10 == 0]

            # 将数据转为Pytorch张量
            self.data = torch.FloatTensor(data[indices])
            self.target = torch.FloatTensor(target[indices])

        # 对特征进行标准化处理（保留前40个特征，对后续特征标准化）均值为 0、标准差为 1
        # 标准化处理（仅对非州特征标准化，州特征为类别编码）
        if not target_only:
            # 全部特征时，对 40 以后的特征标准化
            self.data[:, 40:] = \
                (self.data[:, 40:] - self.data[:, 40:].mean(dim=0, keepdim=True)) \
                / (self.data[:, 40:].std(dim=0, keepdim=True) + 1e-8)  # 加小值避免除零
        else:
            # 仅关键特征时，对 40 以后的 2 个特征标准化（索引 40 和 41）
            self.data[:, 40:] = \
                (self.data[:, 40:] - self.data[:, 40:].mean(dim=0, keepdim=True)) \
                / (self.data[:, 40:].std(dim=0, keepdim=True) + 1e-8)

        self.dim = self.data.shape[1]

        print('Finished reading the {} set of COVID19 Dataset ({} samples found, each dim = {})'
              .format(mode, len(self.data), self.dim))

    def __getitem__(self, index):
        #  返回单个样本
        if self.mode in ['train', 'dev']:
            # For training
            return self.data[index], self.target[index]
        else:
            # For testing (no target)
            return self.data[index]

    def __len__(self):
        # 返回数据集大小
        return len(self.data)


def prep_dataloader(path, mode, batch_size, n_jobs=0, target_only=False):
    #创建数据加载器，从DateSet中加载数据
    dataset = COVID19Dataset(path, mode=mode, target_only=target_only)  # Construct dataset
    dataloader = DataLoader(
        dataset, batch_size,
        shuffle=(mode == 'train'), drop_last=False,
        num_workers=n_jobs, pin_memory=True)   # Construct dataloader
    return dataloader


class NeuralNet(nn.Module):
    #简单的全连接神经网络

    #input_dim为输入的维度
    def __init__(self, input_dim):
        super(NeuralNet, self).__init__()

        # 定义网络结构
        # TODO: How to modify this model to achieve better performance?
        self.net = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.ReLU(),
            nn.Linear(64, 1)
        )

        # 均方差损失函数
        self.criterion = nn.MSELoss(reduction='mean')

    #向前传播方法
    def forward(self, x):
        ''' Given input of size (batch_size x input_dim), compute output of the network '''
        return self.net(x).squeeze(1)
    #损失计算方法
    def cal_loss(self, pred, target,l2_lambda=1e-5):
        ''' Calculate loss '''
        # TODO: you may implement L2 regularization here
        #return self.criterion(pred, target)
        mse_loss = self.criterion(pred, target)
        # L2正则化：对所有参数的平方和求和
        l2_reg = 0.0
        for param in self.parameters():
            l2_reg += torch.norm(param, 2)  # 计算L2范数
        total_loss = mse_loss + l2_lambda * l2_reg  # 合并损失
        return total_loss

#验证函数
def dev(dv_set, model, device):
    model.eval()  # 将模式设置为评估模式
    total_loss = 0
    for x, y in dv_set:  # 遍历验证集中的每个批次
        x, y = x.to(device), y.to(device)  # move data to device (cpu/cuda)
        with torch.no_grad():  # 禁止使用梯度，因为不需要参数更新，可以提高运行速度
            pred = model(x)  # 向前传播，计算预测值
            mse_loss = model.cal_loss(pred, y)  # 计算损失
        total_loss += mse_loss.detach().cpu().item() * len(x)  # 累加当前批次的总损失
    total_loss = total_loss / len(dv_set.dataset)  # 计算整个验证集的平均损失

    return total_loss

#训练函数
'''
参数说明
tr_set：训练集数据加载器（DataLoader）。
dv_set：验证集数据加载器。
model：待训练的神经网络模型（NeuralNet实例）。
config：训练配置字典（包含超参数，如迭代次数、优化器类型等）。
device：训练设备（cpu或cuda）。
'''
def train(tr_set, dv_set, model, config, device):
    ''' DNN training '''

    n_epochs = config['n_epochs']  # Maximum number of epochs

    # 设置优化器
    #分别设置优化器类和超参数hyperparameter
    optimizer = getattr(torch.optim, config['optimizer'])(
        model.parameters(), **config['optim_hparas'])

    min_mse = 1000.#初始化最小的MSE
    loss_record = {'train': [], 'dev': []}  # 记录训练的损失
    early_stop_cnt = 0 #早停计数器（记录验证集损失未改善的轮次）
    epoch = 0 #当前训练的轮次
    # 是不是感觉似曾相识
    while epoch < n_epochs:
        model.train()  # set model to training mode
        for x, y in tr_set:  # 遍历训练集数据加载器
            optimizer.zero_grad()  # 重置梯度（避免上一批次的梯度累积），否则梯度会累积，导致更新错误
            x, y = x.to(device), y.to(device)  # 将数据移至指定设备（CPU/GPU）
            pred = model(x)  # 前向传播：计算模型预测值
            mse_loss = model.cal_loss(pred, y)  # 计算MSE损失
            mse_loss.backward()  # 反向传播：计算参数梯度
            optimizer.step()  # 优化器更新模型参数
            loss_record['train'].append(mse_loss.detach().cpu().item())  # 记录训练损失

        # 每轮次结束后，即一个epoch后，用验证集进行评估
        dev_mse = dev(dv_set, model, device)
        #如果损失下降的话，就更新模型，即更新参数
        if dev_mse < min_mse:
            # Save model if your model improved
            min_mse = dev_mse
            print('Saving model (epoch = {:4d}, loss = {:.4f})'
                  .format(epoch + 1, min_mse))
            torch.save(model.state_dict(), config['save_path'])  # Save model to specified path
            early_stop_cnt = 0
        else:
            early_stop_cnt += 1

        epoch += 1
        loss_record['dev'].append(dev_mse)#记录验证损失
        #如果多个轮次损失都没有改善，那么就停止训练
        if early_stop_cnt > config['early_stop']:
            # Stop training if your model stops improving for "config['early_stop']" epochs.
            break

    print('Finished training after {} epochs'.format(epoch))
    return min_mse, loss_record

#测试函数
def test(tt_set, model, device):
    model.eval()                                # set model to evalutation mode
    preds = []
    for x in tt_set:                            # 遍历测试集中的每个批次
        x = x.to(device)                        # move data to device (cpu/cuda)
        with torch.no_grad():                   # 同样禁用梯度计算
            pred = model(x)                     # 向前传播计算损失
            preds.append(pred.detach().cpu())   # 收集预测结果放到CPU中
    preds = torch.cat(preds, dim=0).numpy()     # 拼接所有批次的预测结果并转换为NumPy数组
    return preds

#设置超参数
device = get_device()  # 获取当前设备('cpu' or 'cuda')
os.makedirs('models', exist_ok=True)  # 模型会被保存到 ./models/
target_only = False  #这里未使用部分特征

# TODO: Using 40 states & 2 tested_positive features

# TODO: How to tune these hyper-parameters to improve your model's performance?
#config保存了训练中所有的超参数
config = {
    'n_epochs': 4000,                # 最大训练轮次
    'batch_size': 64,               # 批次大小
    'optimizer': 'Adam',              # 优化器类型
    'optim_hparas': {                # 优化器超参数
        'lr': 5e-4,                 # 学习率
        #'momentum': 0.9              # SGD动量
        'weight_decay': 1e-6        # 优化器自带的权重衰减（辅助正则化）
    },
    'early_stop': 400,               # 早停阈值（200轮无改善则停止）
    'save_path': 'models/model.pth'  # 模型保存路径
}

#加载数据
tr_set = prep_dataloader('covid.train.csv', 'train', config['batch_size'], target_only=target_only)
dv_set = prep_dataloader('covid.train.csv', 'dev', config['batch_size'], target_only=target_only)
tt_set = prep_dataloader('covid.test.csv', 'test', config['batch_size'], target_only=target_only)

#实例化神经网络，输入维度由训练集特征数（tr_set.dataset.dim）确定。
model = NeuralNet(tr_set.dataset.dim).to(device)  # Construct model and move to device
#调用之前定义的训练函数，返回最小验证损失（model_loss）和损失记录（model_loss_record，包含训练和验证损失）。
model_loss, model_loss_record = train(tr_set, dv_set, model, config, device)
#绘制学习曲线
plot_learning_curve(model_loss_record, title='deep model')

#加载最优模型并可视化预测结果
del model  # 删除当前模型，释放内存
model = NeuralNet(tr_set.dataset.dim).to(device)  # 重新创建模型
ckpt = torch.load(config['save_path'], map_location='cpu')  # 加载保存的最优模型参数
model.load_state_dict(ckpt)  # 将参数加载到新模型中
plot_pred(dv_set, model, device)  # 在验证集上展示预测结果


def save_pred(preds, file):
    ''' Save predictions to specified file '''
    print('Saving results to {}'.format(file))
    with open(file, 'w') as fp:
        writer = csv.writer(fp)
        writer.writerow(['id', 'tested_positive'])
        for i, p in enumerate(preds):
            writer.writerow([i, p])


preds = test(tt_set, model, device)  # predict COVID-19 cases with your model
save_pred(preds, 'pred.csv')  # save prediction file to pred.csv